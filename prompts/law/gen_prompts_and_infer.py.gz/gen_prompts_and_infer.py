#!/usr/bin/env python3

import os
# import glob
import sys

# Traverse the directory in sys.argv[1] and generate the prompts and infer files
# For example we want to find: ~/projects/crawler/snapshot-2023-03-09-text/crawler/raw/ | grep 'hkcfa|2013|39'

def find_files(directory, patterns):
    # Traverse the directory
    for root, dirs, files in os.walk(directory):
        for file in files:
            # Check whether it matches the pattern hkcfa|2013|39
            path = os.path.join(root, file)
            for pattern in patterns:
                if pattern in path:
                    yield path

template = """
### TASKS ###

1. Briefly summarize the facts of the following case.
2. Then, briefly summarize the arguments of the two parties.
3. Finally, summarize the legal principles (ratio decidendi) of the case. Be detailed and thorough. There is no word limit. Use multiple paragraphs. If applicable, focus on the points that might be novel or controversial.

Make sure you separate the three parts clearly.




{case}





### TASKS ###

1. Briefly summarize the facts of the above case.
2. Then, briefly summarize the arguments of the two parties.
3. Finally, summarize the legal principles (ratio decidendi) of the case. Be detailed and thorough. There is no word limit. Use multiple paragraphs. If applicable, focus on the points that might be novel or controversial.

Make sure you separate the three parts clearly.
""".strip() + "\n"


def main():
    if len(sys.argv) <= 2:
        print("Usage: python3 gen_prompts_and_infer.py <directory> <patterns>")
        sys.exit(1)

    directory = sys.argv[1]
    patterns = [s.replace('/', '|') + "." for s in sys.argv[2:]]
    for path in find_files(directory, patterns):
        print(path)
        content = open(path).read()
        # Print the first non-empty line of the file. Skip empty lines.
        print(next(line for line in content.split("\n") if line.strip()))

        # Extract the court, year and case number from filename by assuming that the filename looks like raw-https:||www.hklii.org|eng|hk|cases|hkcfa|2013|38.html.txt
        case_id = path.split("cases|")[1].split(".html.txt")[0]

        # Generate the prompts and infer files from a template
        with open(f"summarize-case-{case_id}.long_prompt", 'w') as f:
            f.write(template.format(case=content))

if __name__ == "__main__":
    main()
